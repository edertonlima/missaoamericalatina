<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'missaoamericalatina');

/** MySQL database username */
define('DB_USER', 'missaoamericalatina');

/** MySQL database password */
define('DB_PASSWORD', '0OLiQ0IBdURxUnwM');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'dbQpkkL7FNZ$ wleOQ(YfWNX*6Q<>0x_0$sf0eBf.P;.B?RfOg_9>kb)$E.5,6Tt');
define('SECURE_AUTH_KEY',  'o+BUFx$kby4sw;x}Z+k=#0T%$>IO8a{K>Dm<flP.HhT**=]+-Mu-jjVK+j`l@d:F');
define('LOGGED_IN_KEY',    'k,BV7U<.)Nq9rP~VAsPGq-e}ruH+DF.YvG,oa+ga!G<=5RXxSSmcOd^>WT-B&q=Q');
define('NONCE_KEY',        '#`6:Dc%_m=wd e(zfKY.3#UG G9s;2C3BhYy4xW40JV.)r;M1 }=)R,ZfgC]~aw(');
define('AUTH_SALT',        '1EgrS^9.q!1v~^FXc IY-yKwTM31$0P]kFe=0B(<2sx`4hnbHw66k<#4gUPH+]XT');
define('SECURE_AUTH_SALT', '_ARKn|Vp_s1J-h#{G;<MPn*M-Sk-=9gc|F_k<oQF8G.a U_.<ta E&52ml<4,2x6');
define('LOGGED_IN_SALT',   've== 1]lD5%A}*I>Q=#1VJT.Umk4VC%XBju6FD Y}N@~bDQH~BYVsu_QW|.nPDQ5');
define('NONCE_SALT',       'z>FAjqv%nfoXj4zpIL!JIFgcNkoxq[uHd7#Flqo3[!2M{Y,`P ]DiM7FP58oD`G1');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
